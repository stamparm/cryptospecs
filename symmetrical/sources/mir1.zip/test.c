#include "mir1.h"


int main(int argc, char* arg)
{
	uc key[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
	uc iv[8]={0,1,2,3,4,5,6,7};
	uc keystream[1024];
	ECRYPT_ctx state;

	ECRYPT_keysetup(&state, key, 128, 64);
	ECRYPT_ivsetup(&state, iv);
    ECRYPT_keystream_bytes(&state, keystream, 1024);

	return 0;
}

