/*
 * REFERENCE IMPLEMENTATION OF STREAM CIPHER GRAIN
 *
 * Filename: testvectors.c
 *
 * Author:
 * Martin Hell
 * Dept. of Information Technology
 * P.O. Box 118
 * SE-221 00 Lund, Sweden,
 * email: martin@it.lth.se
 *
 * Synopsis:
 *    Generates testvectors from the reference implementation of Grain.
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grain.h"

void printData(u8 *key, u8 *IV, u8 *ks) {
	u32 i;
	printf("\n\nkey:        ");
	for (i=0;i<10;++i) printf("%02x",(int)key[i]);
	printf("\nIV :        ");
	for (i=0;i<8;++i) printf("%02x",(int)IV[i]);
	printf("\nkeystream:  ");
	for (i=0;i<10;++i) printf("%02x",(int)ks[i]);
}

void testvectors() {
	
	ECRYPT_ctx ctx;
	u8 key[10],IV[8],ks[10];

	memset(key,0x00,10);
	memset(IV,0x00,8);
	ECRYPT_keysetup(&ctx,key,80,64);
	ECRYPT_ivsetup(&ctx,IV);
	ECRYPT_keystream_bytes(&ctx,ks,10);
	printData(key,IV,ks);

	memset(key,0x44,10);
	memset(IV,0x55,8);
	ECRYPT_keysetup(&ctx,key,80,64);
	ECRYPT_ivsetup(&ctx,IV);
	ECRYPT_keystream_bytes(&ctx,ks,10);
	printData(key,IV,ks);

	memset(key,0xaa,10);
	memset(IV,0xbb,8);
	ECRYPT_keysetup(&ctx,key,80,64);
	ECRYPT_ivsetup(&ctx,IV);
	ECRYPT_keystream_bytes(&ctx,ks,10);
	printData(key,IV,ks);

	printf("\n");

}

int main(int argc, char **argv) {	
	printf("---REFERENCE IMPLEMENTATION OF GRAIN---\n");
	testvectors();
	return 0;
}


