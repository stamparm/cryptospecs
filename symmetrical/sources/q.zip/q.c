#include "nessie.h"

/* the byte substitution s-box */
unsigned byteS[256] = {
 99, 124, 119, 123, 242, 107, 111, 197,  48,   1, 103,  43, 254, 215, 171, 118, 
202, 130, 201, 125, 250,  89,  71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 
183, 253, 147,  38,  54,  63, 247, 204,  52, 165, 229, 241, 113, 216,  49,  21, 
  4, 199,  35, 195,  24, 150,   5, 154,   7,  18, 128, 226, 235,  39, 178, 117, 
  9, 131,  44,  26,  27, 110,  90, 160,  82,  59, 214, 179,  41, 227,  47, 132, 
 83, 209,   0, 237,  32, 252, 177,  91, 106, 203, 190,  57,  74,  76,  88, 207, 
208, 239, 170, 251,  67,  77,  51, 133,  69, 249,   2, 127,  80,  60, 159, 168, 
 81, 163,  64, 143, 146, 157,  56, 245, 188, 182, 218,  33,  16, 255, 243, 210, 
205,  12,  19, 236,  95, 151,  68,  23, 196, 167, 126,  61, 100,  93,  25, 115, 
 96, 129,  79, 220,  34,  42, 144, 136,  70, 238, 184,  20, 222,  94,  11, 219, 
224,  50,  58,  10,  73,   6,  36,  92, 194, 211, 172,  98, 145, 149, 228, 121, 
231, 200,  55, 109, 141, 213,  78, 169, 108,  86, 244, 234, 101, 122, 174,   8, 
186, 120,  37,  46,  28, 166, 180, 198, 232, 221, 116,  31,  75, 189, 139, 138, 
112,  62, 181, 102,  72,   3, 246,  14,  97,  53,  87, 185, 134, 193,  29, 158, 
225, 248, 152,  17, 105, 217, 142, 148, 155,  30, 135, 233, 206,  85,  40, 223, 
140, 161, 137,  13, 191, 230,  66, 104,  65, 153,  45,  15, 176,  84, 187,  22, 
};

/* the inverse byte substitution s-box */
unsigned invbyteS[256] = {
 82,   9, 106, 213,  48,  54, 165,  56, 191,  64, 163, 158, 129, 243, 215, 251, 
124, 227,  57, 130, 155,  47, 255, 135,  52, 142,  67,  68, 196, 222, 233, 203, 
 84, 123, 148,  50, 166, 194,  35,  61, 238,  76, 149,  11,  66, 250, 195,  78, 
  8,  46, 161, 102,  40, 217,  36, 178, 118,  91, 162,  73, 109, 139, 209,  37, 
114, 248, 246, 100, 134, 104, 152,  22, 212, 164,  92, 204,  93, 101, 182, 146, 
108, 112,  72,  80, 253, 237, 185, 218,  94,  21,  70,  87, 167, 141, 157, 132, 
144, 216, 171,   0, 140, 188, 211,  10, 247, 228,  88,   5, 184, 179,  69,   6, 
208,  44,  30, 143, 202,  63,  15,   2, 193, 175, 189,   3,   1,  19, 138, 107, 
 58, 145,  17,  65,  79, 103, 220, 234, 151, 242, 207, 206, 240, 180, 230, 115, 
150, 172, 116,  34, 231, 173,  53, 133, 226, 249,  55, 232,  28, 117, 223, 110, 
 71, 241,  26, 113,  29,  41, 197, 137, 111, 183,  98,  14, 170,  24, 190,  27, 
252,  86,  62,  75, 198, 210, 121,  32, 154, 219, 192, 254, 120, 205,  90, 244, 
 31, 221, 168,  51, 136,   7, 199,  49, 177,  18,  16,  89,  39, 128, 236,  95, 
 96,  81, 127, 169,  25, 181,  74,  13,  45, 229, 122, 159, 147, 201, 156, 239, 
160, 224,  59,  77, 174,  42, 245, 176, 200, 235, 187,  60, 131,  83, 153,  97, 
 23,  43,   4, 126, 186, 119, 214,  38, 225, 105,  20,  99,  85,  33,  12, 125, 
};

/* the bit slice s-boxes in table form */
unsigned sA[16]={0,13,6,8,11,7,1,14,9,10,5,15,2,4,12,3};
unsigned invsA[16]={0,6,12,15,13,10,2,5,3,8,9,4,14,1,7,11};
unsigned sB[16]={0,15,11,8,12,9,6,3,13,1,2,4,10,7,5,14};
unsigned invsB[16]={0,9,10,7,11,14,6,13,3,5,12,2,4,8,15,1};
/* only the forward version is used for keying */
unsigned sC[16]={0,9,10,4,11,7,12,1,13,6,3,15,14,8,5,2};
unsigned invsC[16]={0,7,15,10,3,14,9,5,13,1,2,4,6,8,12,11};
 
void NESSIEkeysetup (const u8 * const key,
		           struct NESSIEstruct * const structpointer)
{
u32 KL[4],KH[4];
int i;
u32 Rcnt=0;

KH[0]=0;
KH[1]=0;
KH[2]=0;
KH[3]=0;
KL[0]=U8TO32_LITTLE(key);
KL[1]=U8TO32_LITTLE(key+4);
KL[2]=U8TO32_LITTLE(key+8);
KL[3]=U8TO32_LITTLE(key+12);

if (KEYSIZE==256)
   {
   KH[0]=U8TO32_LITTLE(key+16);
   KH[1]=U8TO32_LITTLE(key+20);
   KH[2]=U8TO32_LITTLE(key+24);
   KH[3]=U8TO32_LITTLE(key+28);
   }

NESSIEkeyround(KL,KH,Rcnt++);
NESSIEkeyround(KL,KH,Rcnt++);
structpointer->keyW1[0]=KL[0];
structpointer->keyW1[1]=KL[1];
structpointer->keyW1[2]=KL[2];
structpointer->keyW1[3]=KL[3];

NESSIEkeyround(KL,KH,Rcnt++);
structpointer->keyA[0]=KL[0];
structpointer->keyA[1]=ROTL32(KL[0],8);
structpointer->keyA[2]=ROTL32(KL[0],16);
structpointer->keyA[3]=ROTL32(KL[0],24);
structpointer->keyB[0]=KL[1];
structpointer->keyB[1]=ROTL32(KL[1],8);
structpointer->keyB[2]=ROTL32(KL[1],16);
structpointer->keyB[3]=ROTL32(KL[1],24);

for (i=0;i<ROUNDS;i++)
	 {
	 NESSIEkeyround(KL,KH,Rcnt++);
	 structpointer->key[i][0]=KL[0];
	 structpointer->key[i][1]=KL[1];
	 structpointer->key[i][2]=KL[2];
	 structpointer->key[i][3]=KL[3];
	 }

NESSIEkeyround(KL,KH,Rcnt++);
structpointer->keyW2[0]=KL[0];
structpointer->keyW2[1]=KL[1];
structpointer->keyW2[2]=KL[2];
structpointer->keyW2[3]=KL[3];
}

void NESSIEencrypt  (const struct NESSIEstruct * const structpointer,
			  const u8 *const plaintext,
					  u8 *const ciphertext)
{
u32 data[4];
int i;

data[0]=U8TO32_LITTLE(plaintext);
data[1]=U8TO32_LITTLE(plaintext+4);
data[2]=U8TO32_LITTLE(plaintext+8);
data[3]=U8TO32_LITTLE(plaintext+12);

data[0]^=structpointer->keyW1[0];
data[1]^=structpointer->keyW1[1];
data[2]^=structpointer->keyW1[2];
data[3]^=structpointer->keyW1[3];

for (i=0;i<ROUNDS;i++)
    NESSIEround(structpointer,data,data,i);
NESSIEbytesubAB(structpointer,data,data);

data[0]^=structpointer->keyW2[0];
data[1]^=structpointer->keyW2[1];
data[2]^=structpointer->keyW2[2];
data[3]^=structpointer->keyW2[3];

U32TO8_LITTLE(ciphertext,data[0]);
U32TO8_LITTLE(ciphertext+4,data[1]);
U32TO8_LITTLE(ciphertext+8,data[2]);
U32TO8_LITTLE(ciphertext+12,data[3]);
}

void NESSIEkeyround  (u32 KL[4],const u32 KH[4],u32 Rcnt)
{
if (KEYSIZE==256)
    {
    KL[0]^=KH[0];
    KL[1]^=KH[1];
    KL[2]^=KH[2];
    KL[3]^=KH[3];
    }

/* this operation should be byte order independent */
/* more testing is needed on various platforms */
KL[0]^=T8(Rcnt);

NESSIEbytesub(KL,KL);

/* this operation should be byte order independent */
/* more testing is needed on various platforms */
KL[0]^=0x9e3779b9;

NESSIEsboxc(KL,KL);
NESSIEperm(KL,KL);
}

void NESSIEround  (const struct NESSIEstruct * const structpointer,
                  const u32 datain[4],
                   u32 out[4],
                   int r)
{

NESSIEbytesubAB(structpointer,datain,out);

NESSIEsboxa(out,out);

NESSIEperm(out,out);

out[0]^=structpointer->key[r][0];
out[1]^=structpointer->key[r][1];
out[2]^=structpointer->key[r][2];
out[3]^=structpointer->key[r][3];
NESSIEsboxb(out,out);

}

void NESSIEsboxa  (const u32 datain[4],
		           u32 out[4])
{
NESSIEbitslice(sA,datain,out);
}

void NESSIEsboxb  (const u32 datain[4],
		           u32 out[4])
{
NESSIEbitslice(sB,datain,out);
}

void NESSIEsboxc  (const u32 datain[4],
		           u32 out[4])
{
NESSIEbitslice(sC,datain,out);
}

void NESSIEbytesub  (const u32 datain[4],
		           u32 out[4])
{
int i,j;
u8 temp[4];

for (i=0;i<4;i++)
    {
    U32TO8_LITTLE(temp,datain[i]);
    for (j=0;j<4;j++) temp[j]=byteS[temp[j]];
    out[i]=U8TO32_LITTLE(temp);
    }
}

void NESSIEbytesubAB  (const struct NESSIEstruct * const structpointer,
		     const u32 datain[4],
		           u32 out[4])
{
out[0]=datain[0]^structpointer->keyA[0];
out[1]=datain[1]^structpointer->keyA[1];
out[2]=datain[2]^structpointer->keyA[2];
out[3]=datain[3]^structpointer->keyA[3];

NESSIEbytesub(out,out);

out[0]^=structpointer->keyB[0];
out[1]^=structpointer->keyB[1];
out[2]^=structpointer->keyB[2];
out[3]^=structpointer->keyB[3];
}

void NESSIEperm  (const u32 datain[4],
                   u32 out[4])
{
out[0]=datain[0];
out[1]=ROTL32(datain[1],8);
out[2]=ROTL32(datain[2],16);
out[3]=ROTL32(datain[3],24);
}

void NESSIEbitslice (const unsigned sbox[16],
               const u32 datain[4],
		             u32 out[4])
{
u32 temp[4];
u32 b0,b1,b2,b3,v,i;

temp[0]=0;
temp[1]=0;
temp[2]=0;
temp[3]=0;

for (i=0;i<32;i++)
    {
    b0=(datain[0]>>i)&1;
    b1=(datain[1]>>i)&1;
    b2=(datain[2]>>i)&1;
    b3=(datain[3]>>i)&1;
    v=b0+(b1<<1)+(b2<<2)+(b3<<3);
    v=sbox[v];
    b0=v&1;
    b1=(v>>1)&1;
    b2=(v>>2)&1;
    b3=(v>>3)&1;
    temp[0]|=(b0<<i);
    temp[1]|=(b1<<i);
    temp[2]|=(b2<<i);
    temp[3]|=(b3<<i);
    }

out[0]=temp[0];
out[1]=temp[1];
out[2]=temp[2];
out[3]=temp[3];
}

void NESSIEdecrypt  (const struct NESSIEstruct * const structpointer,
		     const u8 *const ciphertext,
		           u8 *const plaintext)
{
u32 data[4];
int i;

data[0]=U8TO32_LITTLE(ciphertext);
data[1]=U8TO32_LITTLE(ciphertext+4);
data[2]=U8TO32_LITTLE(ciphertext+8);
data[3]=U8TO32_LITTLE(ciphertext+12);

data[0]^=structpointer->keyW2[0];
data[1]^=structpointer->keyW2[1];
data[2]^=structpointer->keyW2[2];
data[3]^=structpointer->keyW2[3];

NESSIEibytesubAB(structpointer,data,data);
for (i=ROUNDS;i>0;i--)
    NESSIEiround(structpointer,data,data,i-1);

data[0]^=structpointer->keyW1[0];
data[1]^=structpointer->keyW1[1];
data[2]^=structpointer->keyW1[2];
data[3]^=structpointer->keyW1[3];

U32TO8_LITTLE(plaintext,data[0]);
U32TO8_LITTLE(plaintext+4,data[1]);
U32TO8_LITTLE(plaintext+8,data[2]);
U32TO8_LITTLE(plaintext+12,data[3]);
}

void NESSIEikeyround  (u32 KL[4],const u32 KH[4],const u32 Rcnt)
{
NESSIEiperm(KL,KL);
NESSIEisboxc(KL,KL);

/* this operation should be byte order independent */
/* more testing is needed on various platforms */
KL[0]^=0x9e3779b9;

NESSIEibytesub(KL,KL);

/* this operation should be byte order independent */
/* more testing is needed on various platforms */
KL[0]^=T8(Rcnt);

if (KEYSIZE==256)
    {
    KL[0]^=KH[0];
    KL[1]^=KH[1];
    KL[2]^=KH[2];
    KL[3]^=KH[3];
    }
}

void NESSIEiround  (const struct NESSIEstruct * const structpointer,
                   u32 datain[4],
                   u32 out[4],
                   int r)
{

NESSIEisboxb(out,out);

out[0]^=structpointer->key[r][0];
out[1]^=structpointer->key[r][1];
out[2]^=structpointer->key[r][2];
out[3]^=structpointer->key[r][3];
NESSIEiperm(out,out);
NESSIEisboxa(out,out);
NESSIEibytesubAB(structpointer,datain,out);

}

void NESSIEisboxa  (const u32 datain[4],
		           u32 out[4])
{
NESSIEbitslice(invsA,datain,out);
}

void NESSIEisboxb  (const u32 datain[4],
		           u32 out[4])
{
NESSIEbitslice(invsB,datain,out);
}

void NESSIEisboxc  (const u32 datain[4],
		           u32 out[4])
{
NESSIEbitslice(invsC,datain,out);
}

void NESSIEibytesub  (const u32 datain[4],
		           u32 out[4])
{
int i,j;
u8 temp[4];

for (i=0;i<4;i++)
    {
    U32TO8_LITTLE(temp,datain[i]);
    for (j=0;j<4;j++) temp[j]=invbyteS[temp[j]];
    out[i]=U8TO32_LITTLE(temp);
    }
}

void NESSIEibytesubAB  (const struct NESSIEstruct * const structpointer,
		     const u32 datain[4],
		           u32 out[4])
{
out[0]=datain[0]^structpointer->keyB[0];
out[1]=datain[1]^structpointer->keyB[1];
out[2]=datain[2]^structpointer->keyB[2];
out[3]=datain[3]^structpointer->keyB[3];

NESSIEibytesub(out,out);

out[0]^=structpointer->keyA[0];
out[1]^=structpointer->keyA[1];
out[2]^=structpointer->keyA[2];
out[3]^=structpointer->keyA[3];
}

void NESSIEiperm  (const u32 datain[4],
                   u32 out[4])
{
out[0]=datain[0];
out[1]=ROTL32(datain[1],24);
out[2]=ROTL32(datain[2],16);
out[3]=ROTL32(datain[3],8);
}

