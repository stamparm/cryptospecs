How to generatie the test vectors: 
$rm *.o
$make
$./ecrypt-test > test-vectors.txt