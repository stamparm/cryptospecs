#include "ecrypt-sync.h"

int main()
{
  u32 i;  
  ECRYPT_ctx state;
  u8 key[10]={0,1,2,3,4,5,6,7,8,9};
  u8 iv[10]={0,1,2,3,4,5,6,7,8,9};
  u8 plaintext[10]={0,0,0,0,0,0,0,0,0,0};
  u8 ciphertext[10];
  ECRYPT_init();  
  ECRYPT_keysetup(&state,key,80,80);
  ECRYPT_encrypt_packet(&state,iv,plaintext,ciphertext,10);
  for (i=0;i<10;i++) printf("%x\n",ciphertext[i]);
  return 1;  
}
