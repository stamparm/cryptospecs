/************************************************************************\
 * shark.c                                                              *
 *                                                                      *
 * reference implementation of SHARK                                    *
 * (to be presented at the Cambridge Workshop on                        *
 *   Fast Software Encryption                                           *
 * version E-1.0: nm-bit roundkeys (`exor`)                             *
 *                                                                      *
 * Vincent Rijmen                                                       *
 * December 1995	                                                *
 * Copyright (C): KULeuven.    All rights reserved.			*
 * KULeuven  makes no representations concerning either the		*
 * merchantability of this software or the suitability of this		*
 * software for any particular purpose. It is provided "as is"		*
 * without express or implied warranty of any kind.			*
\************************************************************************/
#include <stdio.h>
#include <stdlib.h>


typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;
typedef long sdword;

#ifdef __alpha
typedef unsigned long ddword;
typedef long sddword;
#else
typedef unsigned long long ddword;
typedef long long sddword;
#endif

#define ROUNDS 6
#define ROUNDKEYS ROUNDS+1
#define KEYLENGTH 16
#define ROOT 0x1f5

#include "boxes1.dat"
#include "boxes2.dat"
/* produced by boxes.c
 */

byte log[256], alog[256];

void print64(FILE *f, ddword a)
/* print ssdwords 
 */
{
   fprintf(f,"%08lx%08lx \n",(dword)(a >> 32), (dword)a);
}

byte mul(byte a, byte b)
/* multiply two elements of GF(2^m)
 */
{
   if (a && b) return alog[(log[a] + log[b])%255];
   else return 0;
}

void init()
/* produce logtabel and alogtabel,
 * needed for multiplying in the field GF(2^m)
 */
{
   word i, j;
   alog[0] = 1;
   for(i = 1; i < 256; i++) { 
      j = alog[i-1] << 1;
      if (j & 0x100) j ^= ROOT;
      alog[i] = j;
      }
   log[0] = 0;
   for(i = 1; i < 255; i++)
      log[alog[i]] = i;
}

ddword transform(ddword a)
/* transform a roundkey
 * we use this when we interchange the key addition 
 * and the linear operation
 */
{
   byte i, j, k[8], t[8];
   ddword r;
   for(i = 0; i < 8; i++) k[i] = (byte)(a >> (56 - 8*i));
   for(i = 0; i < 8; i++) {
      t[i] = mul(iG[i][0],k[0]);
      for(j = 1; j < 8; j++) t[i] ^= mul(iG[i][j],k[j]);
      }
   r = t[0];
   for(i = 1; i < 8; i++) 
      r = (r << 8) ^ t[i];
   return r;
}

ddword encryption(ddword plain, ddword *roundkey)
{
   register ddword tmp = plain;
   register byte r;

   for(r = 0; r < ROUNDS-1; r++) {
      tmp ^= roundkey[r];
      tmp = cbox_enc[0][(tmp >> 56) & 0xff] ^ cbox_enc[1][(tmp >> 48) & 0xff] 
          ^ cbox_enc[2][(tmp >> 40) & 0xff] ^ cbox_enc[3][(tmp >> 32) & 0xff] 
          ^ cbox_enc[4][(tmp >> 24) & 0xff] ^ cbox_enc[5][(tmp >> 16) & 0xff] 
          ^ cbox_enc[6][(tmp >>  8) & 0xff] ^ cbox_enc[7][ tmp        & 0xff];
      }
   tmp ^= roundkey[ROUNDS-1];
   tmp = ((ddword)sbox_enc[(tmp >> 56) & 0xff] << 56) 
       ^ ((ddword)sbox_enc[(tmp >> 48) & 0xff] << 48) 
       ^ ((ddword)sbox_enc[(tmp >> 40) & 0xff] << 40) 
       ^ ((ddword)sbox_enc[(tmp >> 32) & 0xff] << 32)
       ^ ((ddword)sbox_enc[(tmp >> 24) & 0xff] << 24) 
       ^ ((ddword)sbox_enc[(tmp >> 16) & 0xff] << 16)
       ^ ((ddword)sbox_enc[(tmp >>  8) & 0xff] <<  8) 
       ^  (ddword)sbox_enc[ tmp        & 0xff];
   return roundkey[ROUNDS] ^ tmp; 
}

ddword decryption(ddword cipher, ddword *roundkey)
{
   register ddword tmp = cipher;
   register byte r;

   for(r = 0; r < ROUNDS-1; r++) {
      tmp ^= roundkey[r];
      tmp = cbox_dec[0][(tmp >> 56) & 0xff] ^ cbox_dec[1][(tmp >> 48) & 0xff] 
          ^ cbox_dec[2][(tmp >> 40) & 0xff] ^ cbox_dec[3][(tmp >> 32) & 0xff] 
          ^ cbox_dec[4][(tmp >> 24) & 0xff] ^ cbox_dec[5][(tmp >> 16) & 0xff] 
          ^ cbox_dec[6][(tmp >>  8) & 0xff] ^ cbox_dec[7][ tmp        & 0xff];
      }
   tmp ^= roundkey[ROUNDS-1];
   tmp = ((ddword)sbox_dec[(tmp >> 56) & 0xff] << 56) 
       ^ ((ddword)sbox_dec[(tmp >> 48) & 0xff] << 48) 
       ^ ((ddword)sbox_dec[(tmp >> 40) & 0xff] << 40) 
       ^ ((ddword)sbox_dec[(tmp >> 32) & 0xff] << 32)
       ^ ((ddword)sbox_dec[(tmp >> 24) & 0xff] << 24) 
       ^ ((ddword)sbox_dec[(tmp >> 16) & 0xff] << 16)
       ^ ((ddword)sbox_dec[(tmp >>  8) & 0xff] <<  8) 
       ^  (ddword)sbox_dec[ tmp        & 0xff];
   return roundkey[ROUNDS] ^ tmp; 
}

void key_init(byte *key, ddword roundkey_enc[ROUNDKEYS],
                         ddword roundkey_dec[ROUNDKEYS])
{
   ddword tempkey[ROUNDS+1], a[ROUNDKEYS];
   byte i, j, r;
   
   /* initialize the key that will be used
    * to hash the user key to the various round keys 
    */
   for(r = 0; r <= ROUNDS; r++) {
      tempkey[r] = cbox_enc[0][r];
      }
   tempkey[ROUNDS] = transform(tempkey[ROUNDS]);

   /*  a = concatenation of key 
    */
   i = 0;
   for(r = 0; r < ROUNDKEYS; r++) {
      a[r] = key[(i++)%KEYLENGTH];
      for(j = 1; j < 8; j++) {
         a[r] = (a[r] << 8) | key[(i++)%KEYLENGTH];
         }
      }

   /* roundkey_enc = SHARK_CFB(a,tempkey) 
    * roundkey_enc[ROUNDS] has to be transformed, 
    */
   roundkey_enc[0] = a[0] ^ encryption(0LL, tempkey);
   for(r = 1; r < ROUNDKEYS; r++) 
      roundkey_enc[r] = a[r] ^ encryption(roundkey_enc[r-1], tempkey);

   roundkey_enc[ROUNDS] = transform(roundkey_enc[ROUNDS]);
   

   /* de decryption roundkeys are the transformations of the
    * encryption roundkeys in reverse order 
    * (except for 'boundary conditions')
    */
   roundkey_dec[0] = roundkey_enc[ROUNDS];
   roundkey_dec[ROUNDS] = roundkey_enc[0];
   for(r = 1; r < ROUNDS; r++) 
      roundkey_dec[r] = transform(roundkey_enc[ROUNDS-r]);
}

void main()
{
   byte key[KEYLENGTH], i;
   ddword roundkey_enc[ROUNDKEYS], roundkey_dec[ROUNDKEYS];
   ddword q = 0, p;
   init();
   for(i = 0; i < KEYLENGTH; i++) key[i] = i;
   key_init(key, roundkey_enc, roundkey_dec);
   for(i = 0; i < 10; i++) {
      p = q;
      q = encryption(p,roundkey_enc);
      if (decryption(q,roundkey_dec) != p) {
         print64(stdout,p);
         print64(stdout,q);
         }
      }
}
