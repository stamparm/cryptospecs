/************************************************************************\
 * shark.aff.c                                                          *
 *                                                                      *
 * reference implementation of SHARK                                    *
 * (to be presented at the Cambridge Workshop on                        *
 *   Fast Software Encryption                                           *
 * version A-1.0: nm-bit roundkeys (`affine transform`)                 *
 *                                                                      *
 * Vincent Rijmen                                                       *
 * December 1995                                                        *
 * Copyright (C): KULeuven                                              *
 * Copyright (C): KULeuven.    All rights reserved.                     *
 * KULeuven  makes no representations concerning either the             *
 * merchantability of this software or the suitability of this          *
 * software for any particular purpose. It is provided "as is"          *
 * without express or implied warranty of any kind.                     *
\************************************************************************/
#include <stdio.h>
#include <stdlib.h>


typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;
typedef long sdword;

#ifdef __alpha
typedef unsigned long ddword;
typedef long sddword;
#else
typedef unsigned long long ddword;
typedef long long sddword;
#endif

#define ROUNDS 6
#define KEYLENGTH 16
#define ROOT 0x1f5
#define ROUNDKEYS 2*ROUNDS+2

#include "boxes1.dat"
#include "boxes2.dat"

byte log[256], alog[256];
ddword cbox_enc_k[ROUNDS][8][256], cbox_dec_k[ROUNDS][8][256];
byte pG[8][8];

void print64(FILE *f, ddword a)
/* print ssdwords 
 */
{
   fprintf(f,"%08lx%08lx \n",(dword)(a >> 32), (dword)a);
}


byte mul(byte a, byte b)
/* multiply two elements of GF(2^m)
 */
{
   if (a && b) return alog[(log[a] + log[b])%255];
   else return 0;
}

ddword inverse(ddword a)
/* give the ddword that consists of 
 * the 8 bytes that are the multiplicative
 * inverse of the 8 bytes a consists of
 */
{
   byte t;
   ddword r = 0;

   for(t = 0; t < 8; t++) 
      r ^= ((ddword)alog[(255 - log[(byte)(a >> (56 - 8*t))])%255] << (56 - 8*t));
   return r;
}

byte invertible(ddword a)
/* check whether there are no
 * all-zero bytes in a
 */
{
return (byte)a & (byte)(a >> 8) & (byte)(a >> 16) & (byte)(a >> 24)
  & (byte)(a >> 32) & (byte)(a >> 40) & (byte)(a >> 48) & (byte)(a >> 56);
}

void init()
/* produce logtabel and alogtabel,
 * needed for multiplying in the field GF(2^m)
 */
{
   word i, j;
   alog[0] = 1;
   for(i = 1; i < 256; i++) { 
      j = alog[i-1] << 1;
      if (j & 0x100) j ^= ROOT;
      alog[i] = j;
      }
   log[0] = 0;
   for(i = 1; i < 255; i++)
      log[alog[i]] = i;
}

ddword transform(ddword a)
/* transform a roundkey
 * we use this when we interchange the key addition 
 * and the linear operation
 */
{
   byte i, j, k[8], t[8];
   ddword r;
   for(i = 0; i < 8; i++) k[i] = (byte)(a >> (56 - 8*i));
   for(i = 0; i < 8; i++) {
      t[i] = mul(iG[i][0],k[0]);
      for(j = 1; j < 8; j++) t[i] ^= mul(iG[i][j],k[j]);
      }
   r = t[0];
   for(i = 1; i < 8; i++) 
      r = (r << 8) ^ t[i];
   return r;
}


ddword encryption_key(ddword plain, ddword *roundkey)
{
   register ddword tmp = plain;
   register byte r;

   for(r = 0; r < ROUNDS-1; r++) {
      tmp ^= roundkey[r];
      tmp = cbox_enc[0][(tmp >> 56) & 0xff] 
          ^ cbox_enc[1][(tmp >> 48) & 0xff] 
          ^ cbox_enc[2][(tmp >> 40) & 0xff] 
          ^ cbox_enc[3][(tmp >> 32) & 0xff] 
          ^ cbox_enc[4][(tmp >> 24) & 0xff] 
          ^ cbox_enc[5][(tmp >> 16) & 0xff] 
          ^ cbox_enc[6][(tmp >>  8) & 0xff] 
          ^ cbox_enc[7][ tmp        & 0xff];
      }
   tmp ^= roundkey[ROUNDS-1];
   tmp = ((ddword)sbox_enc[(tmp >> 56) & 0xff] << 56) 
       ^ ((ddword)sbox_enc[(tmp >> 48) & 0xff] << 48) 
       ^ ((ddword)sbox_enc[(tmp >> 40) & 0xff] << 40) 
       ^ ((ddword)sbox_enc[(tmp >> 32) & 0xff] << 32)
       ^ ((ddword)sbox_enc[(tmp >> 24) & 0xff] << 24) 
       ^ ((ddword)sbox_enc[(tmp >> 16) & 0xff] << 16)
       ^ ((ddword)sbox_enc[(tmp >>  8) & 0xff] <<  8) 
       ^  (ddword)sbox_enc[ tmp        & 0xff];
   return roundkey[ROUNDS] ^ tmp; 
}

ddword encryption(ddword plain, ddword* roundkey)
{
   register ddword tmp = plain;
   register byte r;

/* first key addition is not
 * incorporated in the cboxes
 */
   tmp = ((ddword)mul(tmp >> 56,roundkey[ROUNDS+1] >> 56) << 56)
       ^ ((ddword)mul((byte)(tmp>>48),(byte)(roundkey[ROUNDS+1]>>48)) << 48)
       ^ ((ddword)mul((byte)(tmp>>40),(byte)(roundkey[ROUNDS+1]>>40)) << 40)
       ^ ((ddword)mul((byte)(tmp>>32),(byte)(roundkey[ROUNDS+1]>>32)) << 32)
       ^ ((ddword)mul((byte)(tmp>>24),(byte)(roundkey[ROUNDS+1]>>24)) << 24)
       ^ ((ddword)mul((byte)(tmp>>16),(byte)(roundkey[ROUNDS+1]>>16)) << 16)
       ^ ((ddword)mul((byte)(tmp>> 8),(byte)(roundkey[ROUNDS+1]>> 8)) <<  8)
       ^ ((ddword)mul((byte)tmp,(byte)roundkey[ROUNDS+1]))
       ^ roundkey[0];

   for(r = 0; r < ROUNDS; r++) {
      tmp = cbox_enc_k[r][0][(tmp >> 56) & 0xff] 
          ^ cbox_enc_k[r][1][(tmp >> 48) & 0xff] 
          ^ cbox_enc_k[r][2][(tmp >> 40) & 0xff] 
          ^ cbox_enc_k[r][3][(tmp >> 32) & 0xff] 
          ^ cbox_enc_k[r][4][(tmp >> 24) & 0xff] 
          ^ cbox_enc_k[r][5][(tmp >> 16) & 0xff] 
          ^ cbox_enc_k[r][6][(tmp >>  8) & 0xff] 
          ^ cbox_enc_k[r][7][ tmp        & 0xff];
      }
   return tmp; 
}

ddword decryption(ddword cipher, ddword *roundkey)
{
   ddword tmp = cipher ^ roundkey[0];
   byte r;
   byte t[8], i, j, u;

/* first key addition is not
 * incorporated in the cboxes
 */
   for(i = 0; i < 8; i++) t[i] = (byte)(tmp >> (56 - 8*i));
   tmp = 0;
   for(i = 0; i < 8; i++) {
      u = 0;
      for(j = 0; j < 8; j++) u ^= mul(pG[i][j],t[j]);
      tmp ^= ((ddword)u << (56 - 8*i));
      }

   for(r = 0; r < ROUNDS; r++) {
      tmp = cbox_dec_k[r][0][(tmp >> 56) & 0xff] 
          ^ cbox_dec_k[r][1][(tmp >> 48) & 0xff] 
          ^ cbox_dec_k[r][2][(tmp >> 40) & 0xff] 
          ^ cbox_dec_k[r][3][(tmp >> 32) & 0xff] 
          ^ cbox_dec_k[r][4][(tmp >> 24) & 0xff] 
          ^ cbox_dec_k[r][5][(tmp >> 16) & 0xff] 
          ^ cbox_dec_k[r][6][(tmp >>  8) & 0xff] 
          ^ cbox_dec_k[r][7][ tmp        & 0xff];
      }
   return tmp; 
}

void box_init(ddword *roundkey_enc, ddword *roundkey_dec)
/*                                encryption   decryption
 * substitution                   sbox_enc     sbox_dec
 * linear diffusion               G            iG
 * matrix for linear transform    kappa        ikappa
 * exor-key                       K            K    
 * whole operation                cbox_enc_k   cbox_dec_k
 *
 *  transform(kappa) = iG * kappa * G
 *  transform(K)     = iG * K
 *
 * encryption operation: (we take the following (!) key addition into cbox_enc)
 *  first R-1 rounds:
 *     cbox_enc(X) = kappa * G * sbox_enc(X) + K
 *  last round:
 *     cbox_enc(X) = transform(kappa) * sbox_enc(X) + transform(K) 
 *                 = iG * kappa * G * sbox_enc(X) + iG * K
 *  
 * decryption operation: (after reordening the operations)
 *  first R-1 rounds:
 *     cbox_dec(Y) = iG * ikappa * (sbox_dec(Y) + K)
 *  last round:
 *     cbox_dec(Y) = ikappa * (sbox_dec(Y) + K)
 */
{
   byte i, j, r, t, G_k[8][8];
   word k;

/* encryption boxes
 */
/* first ROUNDS - 1 rounds
 */
   for(r = 0; r < ROUNDS - 1; r++) {
      for(i = 0; i < 8; i++) 
         for(j = 0; j < 8; j++) 
            G_k[i][j] = mul(G[i][j],(byte)(roundkey_enc[r+ROUNDS+2]>>(56-8*i)));
      for(j = 0; j < 8; j++) 
         for(k = 0; k < 256; k++) {
            cbox_enc_k[r][j][k] = 0;
            for(i = 0; i < 8; i++)
               cbox_enc_k[r][j][k] = (cbox_enc_k[r][j][k] << 8) ^
                                         mul(sbox_enc[k],G_k[i][j]);
            }
      for(k = 0; k < 256; k++)
         cbox_enc_k[r][0][k] ^= roundkey_enc[r+1];
      }
/* last round 
 */    
      for(i = 0; i < 8; i++) 
         for(j = 0; j < 8; j++) {
            G_k[i][j] = 0;
            for(t = 0; t < 8; t++)
               G_k[i][j] ^= 
                  mul(mul(iG[i][t],(byte)(roundkey_enc[2*ROUNDS+1]>>(56-8*t))),
                      G[t][j]);
            }
      for(j = 0; j < 8; j++) 
         for(k = 0; k < 256; k++) {
            cbox_enc_k[ROUNDS-1][j][k] = 0;
            for(i = 0; i < 8; i++)
               cbox_enc_k[ROUNDS-1][j][k] = (cbox_enc_k[ROUNDS-1][j][k] << 8) ^
                                         mul(sbox_enc[k],G_k[i][j]);
            }
      for(k = 0; k < 256; k++)
         cbox_enc_k[ROUNDS-1][0][k] ^= transform(roundkey_enc[ROUNDS]);

   
/* decryption boxes
 */
/* make the decryption keys 
 */
   roundkey_dec[0] = transform(roundkey_enc[ROUNDS]);
   for(r = 1; r <= ROUNDS; r++) 
      roundkey_dec[r] = roundkey_enc[ROUNDS-r];
   for(r = 0; r <= ROUNDS; r++) 
      roundkey_dec[ROUNDS+1+r] = inverse(roundkey_enc[2*ROUNDS+1-r]);

/* first key addition: seperate 
 */
   for(i = 0; i < 8; i++) 
      for(j = 0; j < 8; j++) {
         pG[i][j] = 0;
         for(t = 0; t < 8; t++)
            pG[i][j] ^= 
               mul(mul(iG[i][t],(byte)(roundkey_dec[ROUNDS+1]>>(56-8*t))),
                   G[t][j]);
         }
/* first ROUNDS - 1 rounds
 */
   for(r = 0; r < ROUNDS - 1; r++) {
      for(i = 0; i < 8; i++) 
         for(j = 0; j < 8; j++) 
            G_k[i][j] = mul(iG[i][j],(byte)(roundkey_dec[r+ROUNDS+2]>>(56-8*j)));
      for(j = 0; j < 8; j++) 
         for(k = 0; k < 256; k++) {
            cbox_dec_k[r][j][k] = 0;
            for(i = 0; i < 8; i++)
               cbox_dec_k[r][j][k] = (cbox_dec_k[r][j][k] << 8) ^
               mul(sbox_dec[k] ^ (byte)(roundkey_dec[r+1]>>(56-8*j)),G_k[i][j]);
            }
      }

/* last round 
 */    
      for(i = 0; i < 8; i++) 
         for(j = 0; j < 8; j++) {
            if (i != j) G_k[i][j] = 0;
            else G_k[i][i] = (byte)(roundkey_dec[2*ROUNDS+1]>>(56-8*i));
            }
      for(j = 0; j < 8; j++) 
         for(k = 0; k < 256; k++) {
            cbox_dec_k[ROUNDS-1][j][k] = 0;
            for(i = 0; i < 8; i++)
               cbox_dec_k[ROUNDS-1][j][k] = (cbox_dec_k[ROUNDS-1][j][k] << 8) ^
               mul(sbox_dec[k] ^ (byte)(roundkey_dec[r+1]>>(56-8*i)),G_k[i][j]);
            }
}

void key_init(byte *key, ddword roundkey_enc[ROUNDKEYS])
/* produce the conceptual encryption roundkeys, 
 * without any reordening
 */
{
   ddword tempkey[ROUNDS+1], a[ROUNDKEYS], tmp;
   byte i, j, r, rr;

   /* read tempkey 
    */
   for(r = 0; r <= ROUNDS; r++) {
      tempkey[r] = cbox_enc[0][r];
      }
   tempkey[ROUNDS] = transform(tempkey[ROUNDS]);

   /*  a = concatenation of key 
    */
   i = 0;
   for(r = 0; r < ROUNDKEYS; r++) {
      a[r] = key[(i++)%KEYLENGTH];
      for(j = 1; j < 8; j++) {
         a[r] = (a[r] << 8) | key[(i++)%KEYLENGTH];
         }
      }

   /* conceptual roundkey_enc = SHARK_CFB(a,tempkey) 
    * for r > ROUNDS, roundkey_enc[r] needs to have
    * a multiplicative inverse
    */
   roundkey_enc[0] = a[0] ^ encryption_key(0LL, tempkey);
   for(r = 1; r <= ROUNDS; r++) 
      roundkey_enc[r] = a[r] ^ encryption_key(roundkey_enc[r-1], tempkey);

   r = rr = ROUNDS + 1;
   tmp = roundkey_enc[ROUNDS];
   while (rr < ROUNDKEYS) {
      tmp = a[rr++] ^ encryption_key(tmp, tempkey);
      if (invertible(tmp)) roundkey_enc[r++] = tmp;
      }
   while (r < ROUNDKEYS) {
      tmp = encryption_key(tmp, tempkey);
      if (invertible(tmp)) roundkey_enc[r++] = tmp;
      }
}

