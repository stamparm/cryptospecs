/* has160.c
 * HAS160 : Hash Function Standard
 * Sangwan Kim <yirin@postech.ac.kr>
 * 2000.05.18
 */
#include <stdio.h>

#include "has160.h"

//////////////////////////////////////////////////////////
void has160_input_block(has160_32_block *block) 
{ scanf("%08x", block); }

//////////////////////////////////////////////////////////
void has160_print_block(has160_32_block block) 
{ printf("%08x", block); }

//////////////////////////////////////////////////////////
void has160_print(A, B, C, D, E)
  has160_32_block A, B, C, D, E;
{
  printf(" "); has160_print_block(A);
  printf(" "); has160_print_block(B);
  printf(" "); has160_print_block(C);
  printf(" "); has160_print_block(D);
  printf(" "); has160_print_block(E);
  printf("\n");
}

//////////////////////////////////////////////////////////
has160_32_block has160_f(int r, has160_32_block x,
  has160_32_block y, has160_32_block z)
{
  has160_32_block ret;
  if (r == 0) ret = (x & y) | (~x & z);
  else if (r == 1) ret = x ^ y ^ z;
  else if (r == 2) ret = y ^ (x | ~z);
  else if (r == 3) ret = x ^ y ^ z;
  //printf ("f(%d %08x %08x %08x) = %08x\n", j, x, y, z, ret);
  return ret;
}

//////////////////////////////////////////////////////////
has160_32_block has160_shift(has160_32_block x, int shift)
{
  has160_32_block mask;
  mask = (1 << shift) - 1;
  mask = mask << 32-shift;
  //printf("-- shift --\n");
  //printf("shift = %d, x = %08x\n", shift, x);
  mask = mask & x;
  mask = mask >> 32-shift;
  x = x << shift;
  x = x | mask;
  //printf("x = %08x\n", x);
  return x;
}


//////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
  int i, j, r, k;
  has160_32_block H0, H1, H2, H3, H4;
  has160_32_block A, B, C, D, E, T;
  has160_32_block text[16];
  has160_32_block x[20];

  for (i = 0; i < 16; i++) {
    has160_input_block(text+i);
  }

  printf("text  : \n");
  for (i = 0; i < 16; i++) {
    printf(" ");
    has160_print_block(text[i]);
    if (i == 3 || i == 7 || i == 11) printf("\n");
  }
  printf("\n");

  for (i = 0; i < 16; i++) {
    x[i] = text[i];
  }
  for (i = 16; i < 20; i++) {
    x[i] = 0;
  }

  H0 = 0x67452301;
  H1 = 0xefcdab89;
  H2 = 0x98badcfe;
  H3 = 0x10325476;
  H4 = 0xc3d2e1f0;
  A = H0; B = H1; C = H2; D = H3; E = H4;

  for (r = 0; r < 4; r++) {
    j = 20 * r;

    x[16] = x[has160_l[j+1]] ^ x[has160_l[j+2]]
          ^ x[has160_l[j+3]] ^ x[has160_l[j+4]];
    x[17] = x[has160_l[j+6]] ^ x[has160_l[j+7]]
          ^ x[has160_l[j+8]] ^ x[has160_l[j+9]];
    x[18] = x[has160_l[j+11]] ^ x[has160_l[j+12]]
          ^ x[has160_l[j+13]] ^ x[has160_l[j+14]];
    x[19] = x[has160_l[j+16]] ^ x[has160_l[j+17]]
          ^ x[has160_l[j+18]] ^ x[has160_l[j+19]];

    for (k = 0; k < 20; k++) {
      j =  20 * r + k;

      T = has160_shift(A, has160_s1[k]) + has160_f(r, B, C, D)
        + E + x[has160_l[j]] + has160_K[r];
      E = D;
      D = C;
      C = has160_shift(B, has160_s2[r]);
      B = A;
      A = T;
      printf("j = %d  ", j);
      has160_print(A, B, C, D, E);
    }
  }
  H0 += A; H1 += B; H2 += C; H3 += D; H4 += E;
  has160_print(H0, H1, H2, H3, H4);

  return 0;
}
